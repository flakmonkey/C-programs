/*
 ============================================================================
 Name        : BBaileyDataSorter.c
 Author      : Brett Bailey
 Version     :
 Copyright   : Copyright 2011
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

/*
 *Write a program that:

 1. Asks the user for the name of a file containing input data. The file contains floating point data; one number per line. E.g. :
 -13.5
 29.8
 14.3
 2. Reads data from the input file into an array of floats (max of 20,000 numbers).
 3. Sorts the data using a selection sort (see last page of course notes for a pseudo-code version of this type of sort).
 4. Asks the user for the name of the output file (which is overwritten, if it exists).
 5. Writes the sorted data from the array out to the output file (again, one number per line).

 Tasks 2, 3, and 5 must be performed by functions with suitable names. The function that sorts the data MUST use pointers to do its work (i.e. there should be no square brackets used in that function).

 Extra Credit

 * (2 pts) Add support for command line parameters. If the program is run with no arguments, it runs as described above. If the user includes one argument when running the program, it should use the argument as the input filename, and ask the user the user for the output filename. If the user includes two arguments when running the program, it should use the first argument as the input filename, and the second argument as the output filename (i.e. it should not ask the user for either input or output filenames).
 * (3 pts) Instead of hard-coding the size of the float array, dynamically allocate an array whose length matches the number of items in the file.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

char* readFileToString(char* path);
float* stringToArray(char* text);
int writeDataToFile(char* path, float* fileData);
void sortFloats(float* data); // no angle brackets in this function
void printFloatArray(float* array, int size);

int main(void) {
	char* textData, path;
	float* fileData;

	textData = readFileToString("data");

	printf("\n1.\n%s", textData);

	fileData = stringToArray(textData);

	//printFloatArray(fileData, 2);

	return EXIT_SUCCESS;
}

char* readFileToString(char* path) {
	FILE *fp;
	long fileSize;
	char* text;

	fp = fopen(path, "r");

	if (fp) {
		// Determine number of floats in the file
		fseek(fp, 0, SEEK_END); // Seek the end of the file
		fileSize = ftell(fp); // Ask for the file position marker position
		rewind(fp); // Rewind so that we can read in the text

		// Dynamically allocate enough space for the file and a null terminator
		text = malloc(fileSize + 1);

		fread(text, sizeof(char), fileSize, fp);

		text[fileSize] = '\0';

		fclose(fp);
	} else {
		return NULL;
	}
	return text;
}

float* stringToArray(char* text) {
	int counter = 0;
	char* textTemp = text;
	float* array;

	while ((textTemp = strstr(textTemp, "\n")) != NULL) {
		counter++;
		textTemp++;
	}

	array = malloc(counter + sizeof(float));

	int i;
	for (i = 0; i < counter; i++) {
		*array = atof(text);
		printf("\n2.\n%f",*array);
		array++;
	}

	return array;
}

void printFloatArray(float* array, int size) {
	int i;
	for (i = 0; i < size; i++) {
		printf("\n%f", array[i]);
	}
}
